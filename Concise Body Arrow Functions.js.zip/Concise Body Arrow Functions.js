//main.js


const plantNeedsWater = (day) => {
  return day === 'Wednesday' ? true : false;
};


// refactored plantNeedsWater() to be a concise body:

const plantNeedsWater = day => day === 'Wednesday' ? true : false;


